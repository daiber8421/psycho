import 'package:flutter/material.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form1.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form2.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form3.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form4.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form5.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form6.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form7.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form8.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form9.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form10.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/formularios/form11.dart';

class PageViewForm extends StatefulWidget {
  const PageViewForm({
    super.key,
    required this.studentCourse,
    required this.studentGrade,
    required this.studentId,
    required this.studentName,
  });

  final String studentId;
  final String studentName;
  final String studentGrade;
  final String studentCourse;

  @override
  PageViewFormState createState() => PageViewFormState();
}

class PageViewFormState extends State<PageViewForm> {
 static final PageController pageController = PageController();

 static int currentPage = 0;

 static void nextPage() {
    if (currentPage < 11) { // 10 para reflejar el índice del último formulario
      pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

 static void previousPage() {
    if (currentPage > 0) {
      pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Column(
        children: [
          
        
          Expanded(
            child: PageView(
              controller: pageController,
              onPageChanged: (int page) {
                setState(() {
                  currentPage = page;
                });
              },
              children: [
                _buildFormPage(Form1(
                  studentCourse: widget.studentCourse,
                  studentGrade: widget.studentGrade,
                  studentId: widget.studentId,
                  studentName: widget.studentName,
                )),
                _buildFormPage(Form2()),
                _buildFormPage(Form3()),
                _buildFormPage(Form4()),
                _buildFormPage(Form5()),
                _buildFormPage(Form6()),
                _buildFormPage(Form7()),
                _buildFormPage(Form8()),
                _buildFormPage(Form9()),
                _buildFormPage(Form10()),
                _buildFormPage(Form11()),
              ],
            ),
          ),
         
        ],
      ),
    );
  }

  // pagina con un cuadro blanco y sombra
  Widget _buildFormPage(Widget form) {
    return Padding(
      
      padding: const EdgeInsets.all(16.0),
      child: Container(
         margin: EdgeInsets.only(left: MediaQuery.of(context).size.width>1300? 500: 0,right: MediaQuery.of(context).size.width>1300? 500: 0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              spreadRadius: 2,
              offset: Offset(0, 2), // Sombra hacia abajo
            ),
          ],
        ),
        padding: const EdgeInsets.all(16.0),
        child: form,
      ),
    );
  }
}
