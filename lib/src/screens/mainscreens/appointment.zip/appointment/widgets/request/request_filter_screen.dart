import '../../../../../imports.dart';

class RequestFilterScreen extends StatefulWidget {
  const RequestFilterScreen({
    super.key,
    required this.selectedGrade,
    required this.selectedCourse,
    required this.selectedStatus,
    required this.selectedImportanci,
    required this.selectedDate, 
  });

  final String selectedGrade;
  final String selectedCourse;
  final String selectedStatus;
  final String selectedImportanci;
  final String selectedDate;

  @override
  State<RequestFilterScreen> createState() => _ShowFilterScreenState();
}

class _ShowFilterScreenState extends State<RequestFilterScreen> {
  late String selectedGrade;
  late String selectedCourse;
  late String selectedStatus;
  late String selectedImportanci;
  late String selectedDate;
  late String selectedTypeRequest;

  final List<String> date = [
   "Todos", "sep", "oct", "sic"
  ];

  final List<String> tipo_Sol = [
   "Todos", "RE", "SE",
  ];

  @override
  void initState() {
    super.initState();
    selectedGrade = widget.selectedGrade;
    selectedCourse = widget.selectedCourse;
    selectedStatus = widget.selectedStatus;
    selectedImportanci = widget.selectedImportanci;
    selectedDate = widget.selectedDate;
  }

  // Método para enviar los valores seleccionados de vuelta
  void _applyFilters() {
    Navigator.pop(context, {
      'selectedGrade': selectedGrade,
      'selectedCourse': selectedCourse,
      'selectedStatus': selectedStatus,
      'selectedImportanci': selectedImportanci,
      'selectedDate': selectedDate,
    });
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Filtrar citas"),
        flexibleSpace: Container(
          decoration: AddContainerStyle.appBarGradient,
        ),
      ),
      body: Base(
        background: true,
        width: width,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 15),
            child: Text(
              "Filtrar citas",
              style: AddTextStyle.headContainerBase,
            ),
          ),
          CustomBuilderDropDownButton(
              text: "Grado",
              hint: "Selecciona el grado",
              selected: selectedGrade,
              onChanged: (String? newValue) {
                setState(() {
                  selectedGrade = newValue!;
                });
              }, 
              items: grades.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),                 
            ),
          CustomBuilderDropDownButton(
            text: "Curso",
            hint: "Selecciona el curso",
            selected: selectedCourse,
            onChanged: (String? newValue) {
              setState(() {
                selectedCourse = newValue!;
              });
            }, 
            items: course.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),                 
          ),
          CustomBuilderDropDownButton(
            text: "Estado",
            hint: "Selecciona el estado",
            selected: selectedStatus,
            onChanged: (String? newValue) {
              setState(() {
                selectedStatus = newValue!;
              });
            }, 
            items: tipo_Sol.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),                 
          ),
          CustomBuilderDropDownButton(
            text: "Importancia",
            hint: "Selecciona el grado de importancia",
            selected: selectedImportanci,
            onChanged: (String? newValue) {
              setState(() {
                selectedImportanci = newValue!;
              });
            }, 
            items: gradeIlist.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),                 
          ),
          CustomBuilderDropDownButton(
            text: "Fecha",
            hint: "Selecciona la fecha",
            selected: selectedDate,
            onChanged: (String? newValue) {
              setState(() {
                selectedDate = newValue!;
              });
            }, 
            items: date.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),                 
          ),
          AddBoxStyle.normalBox,
          Button(
            text: "Filtrar",
            onPressed: _applyFilters
          ),
        ],
      ),
    );
  }
}
