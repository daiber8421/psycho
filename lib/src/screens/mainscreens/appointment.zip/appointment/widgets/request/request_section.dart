import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:phsycho/src/screens/mainscreens/appointment/widgets/request/request_card.dart';

import '../../../../../imports.dart';
import '../../service/appointment_service.dart';
import 'request_filter_screen.dart';

class AppointmentRequestSection extends StatefulWidget {
  const AppointmentRequestSection({super.key});

  @override
  State<AppointmentRequestSection> createState() => _AppoinmentRequestState();
}

class _AppoinmentRequestState extends State<AppointmentRequestSection> {
  final String? userRole = SignInState.infoUser["role"];
  final String? userId = SignInState.infoUser["id"];
  final String? psicologaid = SignInState.infoUser["role"] == "0" ? SignInState.infoUser["psicologaid"] : "";
  AppoinmentService service = AppoinmentService();

  // Variables para almacenar los valores seleccionados
  String selectedGrade = "Todos";
  String selectedCourse = "Todos";
  String selectedStatus = "Todos";
  String selectedImportanci = "10";
  String selectedDate = "Todos";

  Future<void> _showFilterScreen() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RequestFilterScreen(
          selectedGrade: selectedGrade,
          selectedCourse: selectedCourse,
          selectedStatus: selectedStatus,
          selectedImportanci: selectedImportanci,
          selectedDate: selectedDate,
        ),
      ),
    );

    if (result != null) {
      setState(() {
        // Actualiza los valores seleccionados con el resultado del filtro
        selectedGrade = result['selectedGrade'] ?? selectedGrade;
        selectedCourse = result['selectedCourse'] ?? selectedCourse;
        selectedStatus = result['selectedStatus'] ?? selectedStatus;
        selectedImportanci = result['selectedImportanci'] ?? selectedImportanci;
        selectedDate = result['selectedDate'] ?? selectedDate;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Base(
      background: true,
      width: width,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Button(text: "Filtrar solicitudes", onPressed: _showFilterScreen,),
        Padding(
          padding: const EdgeInsets.only(bottom: 15),
          child: Text(
            "Visualizar solicitudes y remisiones",
            style: AddTextStyle.headContainerBase,
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
                children: [
                  Chip(label: Text("Grado: $selectedGrade")),
                  Chip(label: Text("Curso: $selectedCourse")),
                  Chip(label: Text("Estado: $selectedStatus")),
                  Chip(label: Text("Importancia: $selectedImportanci")),
                  Chip(label: Text("Fecha: $selectedDate")),
                ],
            ),
          ),
        ),
        AppointmentRequestBuilder(studentid: "1", name: "juan", important: "a", motivo: "as", grado: "sa", course: "df", jornada: "a", psicologaid: "a", description: "a", status: "RE", id: "q", fech: Timestamp(30, 300),),
        AppointmentRequestBuilder(studentid: "2", name: "juan", important: "a", motivo: "as", grado: "sa", course: "df", jornada: "a", psicologaid: "a", description: "a", status: "SE", id: "q", fech: Timestamp(20, 1000),)
      ],
    );
  }
}