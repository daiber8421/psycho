import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:phsycho/src/data/vars.dart';
import 'package:phsycho/src/screens/mainscreens/appointment/service/appointment_service.dart';
import 'package:phsycho/src/screens/mainscreens/appointment/widgets/show/show_card.dart';
import 'package:phsycho/src/screens/mainscreens/other/historial/historial.dart';
//Necesito el asignador de citas
import '../../../../../imports.dart';

class RequestInfoScreen extends StatelessWidget {
  const RequestInfoScreen({super.key, required this.jornada,required this.psicologaid,required this.studenid,required this.name, required this.important, required this.motivo, required this.grade, required this.course, required this.description, required this.status, required this.id});

  final String id;
  final String name;
  final String important;
  final String motivo;
  final String grade;
  final String course;
  final String description;
  final String status;
  //final Timestamp fech;
  final String studenid;
  final String psicologaid;
  final String jornada;
 

  @override
  Widget build(BuildContext context) {

    final width = MediaQuery.of(context).size.width;
      AppoinmentService service = AppoinmentService();
    return Scaffold(
      appBar: AppBar(
        title: Text("Cita de $name"),
        flexibleSpace: Container(
          decoration: AddContainerStyle.appBarGradient,
        ),
      ),
      body: Base(
        background: true,
        width: width,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 15),
          child: Text(
            "Visualizar cita de $name",
            style: AddTextStyle.headContainerBase,
          ),
        ),
          Column(
            children: [
              Text('Nombre: $name'),
              Text('Importancia: $important'),
              Text('Motivo: $motivo'),
              Text('Grado: $grade'),
              Text('Curso: $course'),
              Text('Descripción: $description'),
              Text('Estado: $status', style: status == "Pendiente" ? AddTextStyle.statusPending : status == "Resuelta" ? AddTextStyle.statusDone : status == "Cancelada" ? AddTextStyle.statusCanceled : status == "Activa" ? AddTextStyle.statusActive : null),
              //Text('Fecha: ${service.getFormattedDate(fech)}'), 
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Button(text: "Aceptar solicitud", onPressed: () => {          
              } ),
              Button(text: "Cancelar solicitud"  , onPressed: () => {
              } ),
              Button(text: "Asignar hora",  onPressed: () => {
              }),
            ],
          ),
        ],
      ),
    );
  }
}