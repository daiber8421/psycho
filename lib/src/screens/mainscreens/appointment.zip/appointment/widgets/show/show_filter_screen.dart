import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:phsycho/src/data/styles.dart';
import 'package:phsycho/src/imports.dart';

class ShowFilterScreen extends StatefulWidget {
  const ShowFilterScreen({
    super.key,
    required this.selectedGrade,
    required this.selectedCourse,
    required this.selectedStatus,
    required this.selectedImportanci,
    required this.selectedDate,
  });

  final String selectedGrade;
  final String selectedCourse;
  final String selectedStatus;
  final String selectedImportanci;
  final String selectedDate;

  @override
  State<ShowFilterScreen> createState() => _ShowFilterScreenState();
}

class _ShowFilterScreenState extends State<ShowFilterScreen> {
  late String selectedGrade;
  late String selectedCourse;
  late String selectedStatus;
  late String selectedImportanci;
  late String selectedDate;

  @override
  void initState() {
    super.initState();
    selectedGrade = widget.selectedGrade;
    selectedCourse = widget.selectedCourse;
    selectedStatus = widget.selectedStatus;
    selectedImportanci = widget.selectedImportanci;
    selectedDate = widget.selectedDate;
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020), // Fecha de inicio
      lastDate: DateTime(2101), // Fecha de fin
    );
    if (picked != null && picked != DateTime.now()) {
      setState(() {
        selectedDate = DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  void _applyFilters() {
    Navigator.pop(context, {
      'selectedGrade': selectedGrade,
      'selectedCourse': selectedCourse,
      'selectedStatus': selectedStatus,
      'selectedImportanci': selectedImportanci,
      'selectedDate': selectedDate,
    });
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Filtrar citas"),
        flexibleSpace: Container(
          decoration: AddContainerStyle.appBarGradient,
        ),
      ),
      body: Base(
        background: true,
        width: width,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 15),
            child: Text(
              "Filtrar citas",
              style: AddTextStyle.headContainerBase,
            ),
          ),
          CustomBuilderDropDownButton(
            text: "Grado",
            hint: "Selecciona el grado",
            selected: selectedGrade,
            onChanged: (String? newValue) {
              setState(() {
                selectedGrade = newValue!;
              });
            },
            items: grades.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
          CustomBuilderDropDownButton(
            text: "Curso",
            hint: "Selecciona el curso",
            selected: selectedCourse,
            onChanged: (String? newValue) {
              setState(() {
                selectedCourse = newValue!;
              });
            },
            items: course.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
          CustomBuilderDropDownButton(
            text: "Estado",
            hint: "Selecciona el estado",
            selected: selectedStatus,
            onChanged: (String? newValue) {
              setState(() {
                selectedStatus = newValue!;
              });
            },
            items: status.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
          CustomBuilderDropDownButton(
            text: "Importancia",
            hint: "Selecciona el grado de importancia",
            selected: selectedImportanci,
            onChanged: (String? newValue) {
              setState(() {
                selectedImportanci = newValue!;
              });
            },
            items: gradeIlist.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
          // Reemplazar el dropdown de fecha por un botón que abra un DatePicker
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: ElevatedButton(
              onPressed: () => _selectDate(context),
              child: Text(selectedDate.isEmpty ? 'Selecciona la fecha' : selectedDate),
            ),
          ),
          AddBoxStyle.normalBox,
          Button(
            text: "Filtrar",
            onPressed: _applyFilters,
          ),
        ],
      ),
    );
  }
}

