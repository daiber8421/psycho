import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:phsycho/src/screens/mainscreens/appointment/service/appointment_service.dart';

import 'show_info_screen.dart';
import '../../../../../imports.dart';
import 'package:intl/intl.dart';

AppoinmentService service = AppoinmentService();

class AppointmentBuilder extends StatelessWidget {
  //final Map<String, dynamic> infoU;
  //final Map<String, dynamic> info;
  final String name;
  final String important;
  final String motivo;
  final String grado;
  final String course;
  final String description;
  final String status;
  final String id;
  final String fech;
  
  final String studentid;
  final String jornada;
  final String psicologaid;

  const AppointmentBuilder({
    super.key,
    required this.studentid,
    required this.name,
   
    required this.important,
    required this.motivo,
    required this.grado,
    required this.course,
    required this.fech,
    required this.jornada,
    required this.psicologaid,
    required this.description,
    required this.status,
    required this.id,
  });

  Map<String, dynamic> toMap() {
    return {
      'studentid': studentid,
      'name': name,
      'course': course,
      'grado': grado,
      'important': important,
      'description': description,
      'fech': fech,
      
      'motivo': motivo,
      'jornada': SignInState.infoUser["jornada"],
      'id': id,
      'status': status,
      'psicologaid': psicologaid,
    };
  }

  // Método para formatear la fecha en español

  @override
  Widget build(BuildContext context) {
    return Card(
      child: OpenContainer(
        transitionDuration: const Duration(milliseconds: 500),
        closedBuilder: (ctx, action) => ListTile(
          leading: CircleAvatar(
            backgroundColor: Colours.secondary,
            child: Text(
              name[0],
            ),
          ),
          // Aquí formateamos la fecha correctamente
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    "Importancia: $important, Fecha: $fech, ",
                  ),
                  Text("Estado: $status",
                      style: status == "Pendiente"
                          ? AddTextStyle.statusPending
                          : status == "Resuelta"
                              ? AddTextStyle.statusDone
                              : status == "Cancelada"
                                  ? AddTextStyle.statusCanceled
                                  : status == "Activa"
                                      ? AddTextStyle.statusActive
                                      : null),
                ],
              ),
              Text("Motivo: $motivo")
            ],
          ),
          title: Row(
            children: [
              Text(
                name,
                style: AddTextStyle.titleMedium,
              ),
              const SizedBox(width: 15),
              Text(
                "$course - $grado ",
                style: AddTextStyle.contentSmall,
              ),
            ],
          ),
          trailing: const Icon(Icons.keyboard_arrow_right),
        ),
        openBuilder: (ctx, action) => AppoinmentInfoScreen(
          
            psicologaid: psicologaid,
            jornada: jornada,
            studenid: studentid,
            id: id,
            name: name,
            important: important,
            motivo: motivo,
            grade: grado,
            course: course,
            description: description,
            status: status,
            fech: fech),
      ),
    );
  }
}
