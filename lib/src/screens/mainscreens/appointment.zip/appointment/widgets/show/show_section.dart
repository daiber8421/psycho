import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:phsycho/src/screens/mainscreens/appointment/service/appointment_service.dart';
import 'show_card.dart';
import 'show_filter_screen.dart';
import '../../../../../imports.dart';

class AppointmentShowSection extends StatefulWidget {
  const AppointmentShowSection({super.key});

  @override
  State<AppointmentShowSection> createState() => _AppointmentShowSectionState();
}

class _AppointmentShowSectionState extends State<AppointmentShowSection> {
  final String? userRole = SignInState.infoUser["role"];
  final String? userId = SignInState.infoUser["id"];
  final String? psicologaid = SignInState.infoUser["role"] == "0" ? SignInState.infoUser["psicologaid"] :  SignInState.infoUser["jornada"]=="matinal"? "3":"2";
  AppoinmentService service = AppoinmentService();

  // Variables para almacenar los valores seleccionados
  String selectedGrade = "Todos";
  String selectedCourse = "Todos";
  String selectedStatus = "Pendiente";
  String selectedImportanci = "10";
  String selectedDate = "Todos";

  // Método para actualizar los valores filtrados
  Future<void> _showFilterScreen() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ShowFilterScreen(
          selectedGrade: selectedGrade,
          selectedCourse: selectedCourse,
          selectedStatus: selectedStatus,
          selectedImportanci: selectedImportanci,
          selectedDate: selectedDate,
        ),
      ),
    );

    if (result != null) {
      setState(() {
        // Actualiza los valores seleccionados con el resultado del filtro
        selectedGrade = result['selectedGrade'] ?? selectedGrade;
        selectedCourse = result['selectedCourse'] ?? selectedCourse;
        selectedStatus = result['selectedStatus'] ?? selectedStatus;
        selectedImportanci = result['selectedImportanci'] ?? selectedImportanci;
        selectedDate = result['selectedDate'] ?? selectedDate;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Base(
      background: true,
      width: width,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Button(text: "Filtrar Citas", onPressed: _showFilterScreen),
        Padding(
          padding: const EdgeInsets.only(bottom: 15),
          child: Text(
            "Visualizar citas",
            style: AddTextStyle.headContainerBase,
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Chip(label: Text("Grado: $selectedGrade")),
                Chip(label: Text("Curso: $selectedCourse")),
                Chip(label: Text("Estado: $selectedStatus")),
                Chip(label: Text("Importancia: $selectedImportanci")),
                Chip(label: Text("Fecha: $selectedDate")),
              ],
            ),
          ),
        ),
        StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('Appointments') // Colección principal
              .doc('sede principal') // Documento específico
              .collection("Appoinments-Jornada ${SignInState.infoUser["jornada"]}")
              .doc("Psicologa $psicologaid")
              .collection("Appointments") // Subcolección por jornada
              .where('grado', isEqualTo: selectedGrade == "Todos" ? null : selectedGrade) // Filtro por grado seleccionado
              .where('course', isEqualTo: selectedCourse == "Todos" ? null : selectedCourse) // Filtro por curso seleccionado
              .where('important', isEqualTo: selectedImportanci) // Filtro por importancia
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return const Center(child: Text("No hay citas disponibles."));
            }

            // Filtra las citas según la fecha seleccionada
            final filteredAppointments = snapshot.data!.docs.where((doc) {
              final appointment = doc.data() as Map<String, dynamic>;
              final appointmentDateStr = appointment['fech'] ?? "";
              final appointmentDate = appointmentDateStr.split(" ")[0]; // Extrae solo la parte de la fecha

              // Si se seleccionó "Todos", no filtrar por fecha
              if (selectedDate == "Todos") {
                return true; // Mostrar todas las citas
              }

              // Comparar solo la parte de la fecha
              return appointmentDate == selectedDate;
            }).toList();

            // Mapea los documentos a widgets en lugar de usar itemBuilder
            return ListView(
              scrollDirection: Axis.vertical,
              reverse: false,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: filteredAppointments.map((doc) {
                final appointment = doc.data() as Map<String, dynamic>;

                // Construye el widget personalizado con los datos obtenidos
                return AppointmentBuilder(
                  jornada: appointment["jornada"] ?? "",
                  psicologaid: appointment["psicologaid"] ?? "",
                  studentid: appointment["studentid"],
                  name: appointment['name'],
                  course: appointment['course'],
                  grado: appointment['grado'],
                  description: appointment['description'],
                  important: appointment['important'],
                  motivo: appointment['motivo'],
                  id: appointment["id"],
                  status: appointment['status'] ?? "",
                  fech: appointment['fech'] ?? "",
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}

